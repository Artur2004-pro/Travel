const dotenv = require("dotenv");
dotenv.config({ path: "./config/.env" });

module.exports = process.env;
